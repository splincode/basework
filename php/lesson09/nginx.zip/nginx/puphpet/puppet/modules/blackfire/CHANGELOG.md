# 1.4.0 (2015.12.05)

* Puppet 4 compatibility
* Handle log_level passed as a string (@jtreminio)
* Added apt to manifest as a dependency 


# 1.3.0 (2015.06.01)

* Added support for puppetlabs-apt 2.0
* Added support for Debian 8
* CentOS bugfixes


# 1.2.2 (2015.04.08)

* Bugfixes


# 1.2.1 (2015.04.06)

* Fixed refreshes
* Debian 6 support

